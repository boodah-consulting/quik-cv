<template>
  <q-page class="q-px-xs q-py-xs row flex">
    <span id="caption" class="col-12 text-small text-center" v-html="summaryHtml">
    </span>
    <span id="caption" class="col-12 text-small text-center" v-html="highlightsHtml">
    </span>
    <div class="row">
      <div class="col-8 left-hand-side">
        <JobsComponent :jobs="this.cv.jobs" />
      </div>
      <section class="col-4 right-hand-side">
        <SkillsComponent :skills="this.cv.skills" />
        <ProjectsComponent :projects="this.cv.projects" />
      </section>
    </div>
  </q-page>
</template>

<style></style>

<script>

import JobsComponent from '@components/Recruiter/Jobs.vue'
import ProjectsComponent from '@components/Recruiter/Projects.vue'
import SkillsComponent from '@components/Recruiter/Skills.vue'

import markdownit from 'markdown-it'
const md = markdownit({
  html: true,
  linkify: true,
  typographer: true
})

/**
 *
 * Component used to display the CV as a one pager
 *
 * Usage:
 *   <OnePager />
 *
 * @module OnePager
 *
 */
export default {
  name: 'OnePager',
  props: {
    cv: {
      type: Object,
      required: true
    }
  },
  components: {
    JobsComponent,
    ProjectsComponent,
    SkillsComponent,
  },
  computed: {
    summaryHtml() {
      return md.render(this.cv.summary)
    },
    highlightsHtml() {
      return md.render(this.cv.highlights)
    }
  }
}
</script>
