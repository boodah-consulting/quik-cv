<template>
  <q-layout view="lHh Lpr lFf">
    <ContactInformation />

    <q-page-container>
      <Recruiters :cv="this.recruiters" />
    </q-page-container>
  </q-layout>
</template>

<script>
import recruiters from './data/recruiters.yaml'

import ContactInformation from '@/components/ContactInformation.vue'
import Recruiters from '@views/recruiters.vue'

export default {
  name: 'LayoutDefault',
  data: function () {
    return {
      recruiters,
    };
  },
  components: {
    ContactInformation,
    Recruiters,
  },

}
</script>
